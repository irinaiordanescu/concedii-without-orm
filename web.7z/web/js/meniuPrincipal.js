function openPage() {
    window.open("www.youtube.com");
}